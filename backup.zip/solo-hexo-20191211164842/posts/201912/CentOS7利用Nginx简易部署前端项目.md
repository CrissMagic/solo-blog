title: CentOS7利用Nginx简易部署前端项目
date: '2019-12-10 10:36:12'
updated: '2019-12-10 10:36:12'
tags: [前端, Nginx, Linux]
permalink: /articles/2019/12/10/1575945371968.html
---
![](https://img.hacpai.com/bing/20181002.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# CentOS7利用Nginx部署前端项目
最近研究如何将bpmn-js与vue进行整合，方便工作流开发，但始终出现依赖未找到问题，故采用额外部署前端项目，再在平台引入链接访问的方式，此处记录一下如何简易在Nginx上部署一个前端项目，主要参考[该博客](https://blog.csdn.net/wsbgmofo/article/details/78771255)

1. 下载并解压Nginx，这里以1.4.7为例
```
wget http://nginx.org/download/nginx-1.4.7.tar.gz
tar -zxvf nginx-1.4.7.tar.gz
```
2. 安装gcc等依赖包
```
yum -y install gcc pcre-devel openssl openssl-devel
```
3. 开始安装nginx
```
# cd进入nginx-1.4.7目录内
# 编译
./configure
make&&make install
```
4. 修改配置文件
```
# nginx-1.4.7/conf/nginx.conf
server {
	# 该虚拟主机监听的端口号
        listen       8999;

        # 该虚拟主机访问的域名或ip地址，多个可用空格隔开
        server_name  localhost;

	# 编码
        #charset utf-8;

        #access_log  logs/host.access.log  main;

        location / {
            # nginx下HTML文件夹，访问上述域名会检索此文件夹下的文件进行访问
            # 可以将上传的dist目录修改为项目名
            root   html/bpmn;
            # 输入网址（server_name：port）后，默认的访问页面
            index  index.html index.htm;
        }

```
5. 上传前端dist文件夹至/usr/local/nginx/html，修改dist与上述配置文件配置的root后的路径一致

6. 启动,默认安装在/usr/local/nginx/sbin/nginx
```
/usr/local/nginx/sbin/nginx -c /nginx-1.4.7/conf/nginx.conf
```
7. 其他命令
```
# 切换至/usr/local/nginx/sbin目录
cd /usr/local/nginx/sbin
# fast shutdown
./nginx -s stop
# graceful shutdown
./nginx -s quit
# reloading the configuration file
./nginx -s reload
# reopening the log files
./nginx -s reopen
```
