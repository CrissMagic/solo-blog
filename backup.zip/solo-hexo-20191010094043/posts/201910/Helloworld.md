title: Hello,world！
date: '2019-10-09 16:46:37'
updated: '2019-10-09 17:38:32'
tags: [欢迎]
permalink: /hello-solo
---
## 欢迎来到CrissMagic的个人博客

![一人行者壁纸.jpg](https://img.hacpai.com/file/2019/10/一人行者壁纸-8142970c.jpg)

+ 该博客使用Solo开源搭建，后期会在此基础上扩展个人网站的其他内容，个人域名也还在审核备案中。
+ 目前先这样吧，之后再慢慢补充内容。


