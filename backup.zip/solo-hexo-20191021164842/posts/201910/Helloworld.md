title: Hello,world！
date: '2019-10-09 16:46:37'
updated: '2019-10-21 11:32:21'
tags: [待分类]
permalink: /hello-solo
---
![](https://img.hacpai.com/bing/20180511.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 欢迎来到CrissMagic的个人博客

这里是CrissMagic，目前从事Java后台和大数据开发工作，喜爱IT技术，爱好ACGN文化、魔术、VOCALOID、Adobe全家桶等。网站名取材于ilem的歌曲《一人行者》，名字取材于美国著名魔术师CrissAngel，他也是我在魔术方面的偶像之一。

此网站使用Solo开源博客搭建，后期会在此基础上扩展为个人网站，主要用于分享我个人的技术博客、一些事物的评测以及生活方面的感想，欢迎各位评论吐槽。


