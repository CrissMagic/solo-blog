title: Linux常用操作整理
date: '2019-10-11 10:07:21'
updated: '2019-10-11 10:07:21'
tags: [Linux]
permalink: /articles/2019/10/11/1570759641494.html
---
![](https://img.hacpai.com/bing/20171225.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

以目前的经验，在操作公司服务器或者电脑虚拟机时，或多或少会遇到一些固定的问题或者是忘记的命令，网上搜索时解决方式很多但是不一定适合自己，这里做一个归纳整理，都是我自己试过能解决问题的，以备后期查阅。

1. 若有自带安装的 JDK，如何卸载 CentOS 系统自带 Java 环境？

   + 卸载 JDK 相关文件
     输入：`yum -y remove java-1.7.0-openjdk*`
   + 卸载 tzdata-java
     输入：`yum -y remove tzdata-java.noarch`
2. 防火墙的基本操作(CentOS)

   + 启动： `systemctl start firewalld`
   + 关闭： `systemctl stop firewalld`
   + 查看状态： `systemctl status firewalld`
   + 开机禁用  ： `systemctl disable firewalld`
   + 开机启用  ： `systemctl enable firewalld`
3. 修改 CentOS 默认 yum 源为 mirrors.aliyun.com

   + 首先备份系统自带 yum 源配置文件 CentOS-Base.repo
     `# mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bak`
   + 下载 ailiyun 的 yum 源配置文件到/etc/yum.repos.d/
     CentOS7
     `# wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo`
   + 运行 yum makecache 生成缓存
     `# yum makecache`
   + 这时候再更新系统就会看到以下 mirrors.aliyun.com 信息
     ![QQ 截图 20191011094714.png](https://img.hacpai.com/file/2019/10/QQ%E6%88%AA%E5%9B%BE20191011094714-ae5e67bb.png)
4. yum 程序占用
   曾经遇到过如下错误：

   ```
   Existing lock /var/run/yum.pid: another copy is running as pid 25960.
   Another app is currently holding the yum lock; waiting for it to exit...
   ```

   搜索后发现此时可以强制关掉 yum 进程：
   `#rm -f /var/run/yum.pid`
5. 查看端口
   `netstat -lntup`
6. 安装完 Node.js 后 NPM 安装依赖缓慢
   此时可换为换为国内源
   `npm config set registry http://registry.npm.taobao.org`
7. su: Authentication failure 的解决方案

> 原因是：Ubuntu 默认不允许使用 root 登录，因此初始 root 账户是不能使用的，需要在普通账户下利用 sudo 权限修改 root 密码。

解决方案很简单，设置一个 root 密码就行了。
注意是 sudo 而不是 su：`sudo passwd root`
8. Ubuntu 的一些操作
+ 关闭防火墙
`sudo ufw disable`
+ 查看状态
`sudo ufw status`
+ 卸载 openjdk
`sudo apt-get remove openjdk*`
9. Ubuntu 保存环境变量的几个文件
+ /etc/profile
在用户登录时，操作系统定制用户环境时使用的第一个文件，此文件为系统的每个用户设置环境信息，当用户第一次登录时，该文件被执行。

+ /etc/environment
在用户登录时，操作系统使用的第二个文件， 系统在读取用户个人的 profile 前，设置环境文件的环境变量。

+ ~/.profile
在用户登录时，用到的第三个文件 是.profile 文件，每个用户都可使用该文件输入专用于自己使用的 shell 信息，当用户登录时，该文件仅仅执行一次！默认情况下，会设置一些环境变量，执行用户的.bashrc 文件。
+ /etc/bashrc
为每一个运行 bash shell 的用户执行此文件，当 bash shell 被打开时，该文件被读取。
+ ~/.bashrc
该文件包含专用于用户的 bash shell 的 bash 信息，当登录时以及每次打开新的 shell 时，该该文件被读取。
>注意：以上文件可通过$ sudo gedit 文件名 或 $ sudo VIM 文件名打开；建议只修改 ~/.profile 文件，如果只修改 ~/.bashrc 文件，后期使用 go get 命令时，会提示 GOPATH 未设置。
