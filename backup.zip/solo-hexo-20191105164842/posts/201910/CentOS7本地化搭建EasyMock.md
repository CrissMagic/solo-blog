title: CentOS7本地化搭建Easy-Mock
date: '2019-10-30 09:17:44'
updated: '2019-10-30 09:18:06'
tags: [后端, Linux, Mock]
permalink: /articles/2019/10/30/1572398264251.html
---
# CentOS7本地化搭建Easy-Mock

>Easy-Mock是一款个人使用较为舒服的mock框架，在开发时可以较为方便地自定义mock数据结构，并且可以无缝对接Swagger。官网目前提供了对应的docker镜像，目前已按照此方法部署在该ECS实例上。

下面是具体步骤可做参考：

## yum升级
```
yum update
```
## 安装依赖
```
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```
## 安装最新社区版docker
```
sudo yum install docker-ce docker-ce-cli containerd.io
```
## 启动Docker
```
sudo systemctl start docker
```
### 其他可能用到的命令
##### 停止
```
sudo systemctl stop docker
```
##### 重启
```
sudo systemctl restart docker
```
## 安装docker-compose
```
sudo curl -L "https://github.com/docker/compose/releases/download/1.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
```
## 添加可执行权限
```
sudo chmod +x /usr/local/bin/docker-compose
```
## 添加easy-mock配置文件
```
    # docker-compose.yml
    version: '3'
    
    services:
      mongodb:
        image: mongo:3.4
        volumes:
          # ./data/db 数据库文件存放地址，根据需要修改为本地地址
          - './data/db'
        networks:
          - easy-mock
        restart: always
    
      redis:
        image: redis:4.0.6
        command: redis-server --appendonly yes
        volumes:
          # ./data/redis redis 数据文件存放地址，根据需要修改为本地地址
          - './data/redis'
        networks:
          - easy-mock
        restart: always
    
      web:
        image: easymock/easymock:1.6.0
        command: /bin/bash -c "npm start"
        ports:
          - 7300:7300
        volumes:
          # 日志地址，根据需要修改为本地地址
          - './logs'
          # 配置地址，请使用本地配置地址替换
          # - './production.json'
        networks:
          - easy-mock
        restart: always
    
    networks:
      easy-mock:
```
## 新建production.json
```
{
  "port": 7300,
  "host": "0.0.0.0",
  "pageSize": 30,
  "proxy": false,
  "db": "mongodb://localhost/easy-mock",
  "unsplashClientId": "",
  "redis": {
    "keyPrefix": "[Easy Mock]",
    "port": 6379,
    "host": "redis",
    "password": "",
    "db": 0
  },
  "blackList": {
    "projects": [], // projectId, e.g."5a4495e16ef711102113e500"
    "ips": [] // ip, e.g. "127.0.0.1"
  },
  "rateLimit": { // https://github.com/koajs/ratelimit
    "max": 1000,
    "duration": 1000
  },
  "jwt": {
    "expire": "14 days",
    "secret": "shared-secret"
  },
  "upload": {
    "types": [".jpg", ".jpeg", ".png", ".gif", ".json", ".yml", ".yaml"],
    "size": 5242880,
    "dir": "../public/upload",
    "expire": {
      "types": [".json", ".yml", ".yaml"],
      "day": -1
    }
  },
  "ldap": {
    "server": "", // Set server to enable LDAP login. e.g. "ldap://localhost:389" or "ldaps://localhost:389"（use SSL）
    "bindDN": "", // Username，e.g. "cn=admin,dc=example,dc=com"
    "password": "",
    "filter": {
      "base": "", // Base where we can search for users，e.g. "dc=example,dc=com"
      "attributeName": "" // e.g. "mail" or "email" etc.
    }
  },
  "fe": {
    "copyright": "",
    "storageNamespace": "easy-mock_",
    "timeout": 25000,
    "publicPath": "/dist/"
  }
}
```
## 启动Docker-Compose
```
docker-compose up -d
```
## 其他命令
```
# 停止
docker-compose stop
# 查看运行状态
docker-compose ps
# 查看运行日志
docker-compose logs
```
