title: CentOS7搭建CDH5.16.2
date: '2019-11-08 17:18:15'
updated: '2019-11-10 18:48:25'
tags: [CDH, 大数据, Linux]
permalink: /articles/2019/11/08/1573204695172.html
---
![](https://img.hacpai.com/bing/20190228.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# CentOS7 搭建 CDH5.16.2

## 写在前面

很久之前就想在虚拟机上通过 CDH 搭建大数据集群，但是因为种种原因，还有网上博客的各种坑，一直到最近才安装成功，这里分享一下我自己整理后的安装步骤。自己主要在虚拟机 VMWare 上进行安装，但是参考的博客是在 ECS 上安装的，所以都可以进行参考。这里附上本文所用的软件链接：[nlyn](https://pan.baidu.com/s/1sQzZ7BMZhqtPPETfTHXmvw )

> [参考博客](https://blog.csdn.net/chenhai201/article/details/78856007)。需要注意的是，按照[该博客](https://blog.csdn.net/chenhai201/article/details/78856007)安装 5.14.1 会导致在安装 CM 时卡在 40%的地方，根据文章下方的评论，建议直接安装最新版 cdh，故此处安装 CDH5.16.2

## 一、虚拟机配置与 CentOS7 环境安装

自身配置时注意更换 hostname

### 个人虚拟机配置：

```
master 192.168.211.128 2*1核 5G+30G
slave1 192.168.211.129 1*1核 1G+20G
slave2 192.168.211.130 1*1核 1G+20G
slave3 192.168.211.131 1*1核 1G+20G

个人安装的版本为CentOS-7-x86_64-DVD-1908，安装时均选择最小安装。
```

> 需要注意的是，后期在 Web 页面会进行集群安装，这个时候需要密码登录或者私钥登录所有节点，故此处采用密码登录，**所有节点配置了相同的 root 密码**

### 最小安装后的联网设置以及 yum 更新

```
# 所有节点均要配置
# 配置ifcfg-ens33，若配置不叫ens33可换为对应的名字
$ vi /etc/sysconfig/network-script/ifcfg-ens33

TYPE="Ethernet"
PROXY_METHOD="none"
BROWSER_ONLY="no"
BOOTPROTO="static" # 改为静态ip
DEFROUTE="yes"
IPV4_FAILURE_FATAL="no"
IPV6INIT="yes"
IPV6_AUTOCONF="yes"
IPV6_DEFROUTE="yes"
IPV6_FAILURE_FATAL="no"
IPV6_ADDR_GEN_MODE="stable-privacy"
NAME="ens33"
UUID="c29990a8-f310-46b8-bf73-1e31e92ec3af"
DEVICE="ens33"
ONBOOT="yes" # 改为开机启动
IPADDR=192.168.211.128 # 修改对应ip地址
NETMASK=255.255.255.0 # 修改子网掩码
GATEWAY=192.168.211.2 # 修改网关与虚拟机网络配置中的网关相同
DNS1=8.8.8.8 # 添加DNS
DNS2=114.114.114.114

# 重启网络
$ systemctl restart network

# ping外网
$ ping www.baidu.com

# yum更新（可更换yum源）
$ yum update

# 安装wget
$ yum install -y wget

# 安装net-tools
$ yum install -y net-tools

# 安装vim
$ yum install -y vim
```

### 配置基本环境

#### 最小安装不带 OpenJDK，此处省略卸载步骤，采用 rpm 本地安装 jdk8

```
# 所有节点均要配置
# 上传jdk安装包与Oracle依赖
# rpm本地安装
rpm -ivh jdk-8u65-linux-x64.rpm
rpm -ivh oracle-j2sdk1.7-1.7.0+update67-1.x86_64.rpm #CM安装需要这个，否则会重新联网下载，造成安装速度非常缓慢

# rpm安装会自动配置环境变量，采用其他方式安装需配置环境变量，此处省略

# 检查jdk安装情况
$ java -version
```

#### 设置 hosts 与 SSH

```
# 所有节点修改hostname
$ hostnamectl --static set-hostname master

# 所有节点修改hosts
$ vim /etc/hosts

# 在文件后追加
192.168.211.128 master
192.168.211.129 slave1
192.168.211.130 slave2
192.168.211.131 slave3

# 关闭防火墙
$ systemctl stop firewalld.service #停止firewall
$ systemctl disable firewalld.service #禁止firewall开机启动
$ firewall-cmd --state #查看默认防火墙状态（关闭后显示not running，开启后显示running）

# 关闭selinux：
vim /etc/selinux/config

# 找到SELINUX改为：
SELINUX=disabled

# 设置ssh
# 先在master上执行：
$ ssh-keygen -t rsa   #一路回车到完成
$ ssh-copy-id -i ~/.ssh/id_rsa.pub root@master   #将公钥拷贝到本机的authorized_keys上

# 再在其他节点分别执行以下命令：
$ ssh-keygen -t rsa   #一路回车到完成
$ ssh-copy-id -i ~/.ssh/id_rsa.pub root@master   #注意此处不变，将公钥拷贝到master的authorized_keys上

# 在master上，将authorized_keys分发到其他节点服务器：
$ scp ~/.ssh/authorized_keys root@serve1:~/.ssh/
$ scp ~/.ssh/authorized_keys root@serve2:~/.ssh/
$ scp ~/.ssh/authorized_keys root@serve3:~/.ssh/
```

#### 重启所有节点服务器

```
# 重启服务器使配置生效
$ reboot
```

#### 安装 ntp 时间同步软件

```
$ yum install -y ntp

# 配置NTP，在master节点
$ vim /etc/ntp.conf

# 修改成如下配置，此处采用国家ntp时间同步中心，原博给的地址目前已无法同步：
server ntp.ntsc.ac.cn prefer

server 0.centos.pool.ntp.org iburst
server 1.centos.pool.ntp.org iburst
server 2.centos.pool.ntp.org iburst
server 3.centos.pool.ntp.org iburst
# 然后先进行一次时间同步：
$ /usr/sbin/ntpdate ntp.ntsc.ac.cn

# 在salve1~3上，修改/etc/ntp.conf配置改为以下
server master
server 0.centos.pool.ntp.org iburst
server 1.centos.pool.ntp.org iburst
server 2.centos.pool.ntp.org iburst
server 3.centos.pool.ntp.org iburst

# 子节点需要定期同步主节点的时间，所以需要在各个子节点增加一个定时任务：
# 每个从节点，从master节点同步时间
$ ntpdate master

# 做一个计划任务（从节点）
$ crontab -e

# 表示每3小时同步一次时间
00 */3 * * * /usr/sbin/ntpdate  master >> /root/ntpdate.log 2>&1

# 查看计划任务
$ crontab  -l

# 所有子节点ntp加入开机启动
$ chkconfig ntpd on

# 最后所有服务器检查一下时间是否一致即可。
```
## 二、CM与CDH安装
### 上传本地安装文件
为了便于执行命令，在所有节点中创建~/soft/目录，并按照下表上传安装文件

|服务器|用途|所需文件|
|---|---|---|
|master| 主  |cloudera-manager-agent-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>cloudera-manager-daemons-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>cloudera-manager-server-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>cloudera-manager-server-db-2-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>enterprise-debuginfo-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>cloudera-manager-installer.bin</br>cloudera-manager.repo</br>CDH-5.16.2-1.cdh5.16.2.p0.8-el7.parcel</br>CDH-5.16.2-1.cdh5.16.2.p0.8-el7.parcel.sha1
|slave1~3| 从 |cloudera-manager-agent-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>cloudera-manager-daemons-5.16.2-1.cm5162.p0.7.el7.x86_64.rpm</br>cloudera-manager.repo

### master主机安装
~~~
# 切换目录
$ cd ~/soft

# 修改仓库文件cloudera-manager.repo，把版本号加上
[cloudera-manager]
name = Cloudera Manager
baseurl = https://archive.cloudera.com/cm5/redhat/7/x86_64/cm/5.16.2/  #主要改这里的版本号
gpgkey = https://archive.cloudera.com/redhat/cdh/RPM-GPG-KEY-cloudera
gpgcheck = 1

# 开始master的安装：
$ yum localinstall --nogpgcheck *.rpm
~~~
### 从机安装
~~~
# 参照上述同样修改cloudera-manager.repo

# 开始slave1~3的安装：
$ yum localinstall --nogpgcheck *.rpm

# 最后在slave1~3节点检查我们安装包
$ yum list | grep cloudera
~~~
### 安装cloduera manager二进制安装包
~~~
# 进入master的cloudera-manager-installer.bin所在目录
# 设置安装权限：
$ chmod u+x cloudera-manager-installer.bin

# 执行安装命令:
$ ./cloudera-manager-installer.bin

# 如果提示需要删除配置文件，则备份文件
$ mv /etc/cloudera-scm-server/db.properties /etc/cloudera-scm-server/db.properties.bak
~~~
重新执行安装命令，根据安装向导一路next。注意，如果之前master上没有手动安装rpm包此时就会联网下载，下载速度一般都较慢，太费时间。

相同配置下顺利安装时间在1分钟内即可完成。
然后我们在web浏览器访问 http://192.168.211.128:7180/
看是否能打开页面即可，先不要进行登录操作。

>注意：chd server服务器启动需要一些时间，等1分钟左右。

如果能访问，那证明 cloudera manager安装正常。

### CDH服务安装
#### 制作本地parcel
前面完成cloudera manager安装之后master会在/opt目录下生成cloudera文件夹，将之前下载好的CDH-*文件移动到parcel-repo文件夹中
~~~
$ mv CDH-5.16.2-1.cdh5.16.2.p0.8-el7.parcel /opt/cloudera/parcel-repo/
$ mv CDH-5.16.2-1.cdh5.16.2.p0.8-el7.parcel.sha1 /opt/cloudera/parcel-repo/CDH-5.16.2-1.cdh5.16.2.p0.8-el7.parcel.sha  #注意这里有重命名

# 将cloudera manager的用户授权给/opt和日志目录：
$ chown cloudera-scm.cloudera-scm  /opt  -R
$ chown cloudera-scm.cloudera-scm  /var/log/cloudera-scm-agent -R

# 重启cloudera-scm-server（重要）
$ /etc/init.d/cloudera-scm-server restart
~~~
重启速度较慢，约1分钟后访问 http://192.168.211.128:7180/ 
登陆，账号密码 admin
选择免费版本，开始安装。

#### 安装CDH
此步骤的安装图可参考[原博客](https://blog.csdn.net/chenhai201/article/details/78856007)
1. 为CDH集群安装指定主机
	框中输入：192.168.211.[128-131]
	搜索并全选添加继续
2. 集群安装
	默认Parcel安装，选择CDH版本为5.16.2，其余保持默认即可
3. JDK安装
	我们已经安装了JDK8所以不勾选直接继续
4. 启用单用户模式
	暂时不使用单用户模式，简化安装
5. 提供SSH登录凭据
	使用root用户，所有主机接受相同密码，继续
6. 等待安装完成
7. 集群设置
	建议先安装核心Hadoop，后期有需要再进行添加
8. 数据库设置
	有独立的数据库可以配置独立数据库，没有的可以使用自带的嵌入式数据库，使用自带数据库建议将密码截一下图
9. 等待安装完成

## 写在最后
其实根据目前这个配置运转CDH是比较勉强的，安装完进入页面后会发现一大堆的警告报警，可以选择提高服务器配置（~~调低报警阈值~~）来解决
