title: Git本地仓库关联、解除关联远程仓库流程及遇到的问题
date: '2019-10-24 10:29:16'
updated: '2019-10-24 10:29:16'
tags: [问题解决, git]
permalink: /articles/2019/10/24/1571884156680.html
---
![](https://img.hacpai.com/bing/20171111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

开发过程中需要将自己的代码用git做版本管理，那么此时需要将本地仓库与远程仓库进行关联，此处记录一下相关流程以及遇到的问题和处理方式

## 关联远程仓库

以Github平台为例，GitLab、Gitee类似

1. 在github上面创建一个空的仓库

2. 在Git Bash上输入如下命令，将本地仓库与远程仓库关联
```
#git初始化
$ git init
#设置remote地址
$ git remote add github 地址
#将全部文件加入git版本管理 .的意思是将当前文件夹下的全部文件放到版本管理中
$ git add .
#提交文件 使用-m 编写注释
$ git commit -m "注释"
#推送到远程分支
$ git push
```
>这里需要注意的是上面命令中的**github**是远程仓库在本地Git的名称，默认情况下一般命名为origin，但是这里为了区分不同平台的远程仓库（例如：Gitee平台的远程仓库在本地可以命名为gitee），所以为github。仓库地址为你建立的新仓库的地址

查看本地仓库与远程仓库的关联详情
```
$ git remote -v
```
还有一种情况是，远程仓库里已经有文件，这时候你执行上面的步骤是不可以的，因为需要把远程仓库的文件先更新下来。步骤如下
```
# git初始化
$ git init
# 设置remote地址
$ git remote add github 地址
# 获取远程仓库master分支上的内容
$ git pull origin master
# 将当前分支设置为远程仓库的master分支
$ git branch --set-upstream-to=origin/master master
# 将全部文件加入git版本管理 .的意思是将当前文件夹下的全部文件放到版本管理中
$ git add .
# 提交文件 使用-m 编写注释
$ git commit -m "注释"
# 推送到远程分支
$ git push
```
之后就可以进行add、commit、push等操作了

## 解除远程仓库
删除与远程仓库的关联就比较简单了，直接输入以下命令：
```
$ git remote rm github
```

## 遇到的问题
在将自己的代码保管至公司GitLab上是出现了问题，按照上面的流程输入```git branch --set-upstream-to=origin/master master```后，bash报错
```
fatal: branch 'master' does not exist
```
此时的问题是本地仓库并不在master分支上，所以需要先切换到master分支
```
$ git checkout master
Already on 'master'
Branch 'master' set up to track remote branch 'master' from 'origin'.
```
之后则可正常进行添加、提交等操作

## 设置仓库级别的用户名和邮箱
有时候需要使用多个git帐号，就对应的需要配置多个用户名和密码，git 配置相关的命令为 git config，这里顺便记录一下修改方式
```
#查看当前全部的配置
git config -l
```
执行这个命令会进入一个配置文件页，使用vim编辑器的推出命令退出 :wq
```
#全局级配置，如果没有仓库级别的特殊配置，默认读取这个配置
git config --global user.name "name"
git config --global user.email "email"

#仓库级配置，一般一个项目配置一次
git config user.name "name"
git config user.email "email"
```
