title: Hello,world！
date: '2019-10-09 16:46:37'
updated: '2019-10-10 10:54:59'
tags: [欢迎]
permalink: /hello-solo
---
![](https://img.hacpai.com/bing/20180511.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 欢迎来到CrissMagic的个人博客

+ 该博客使用Solo开源搭建，后期会在此基础上扩展个人网站的其他内容，个人域名也还在审核备案中。
+ 目前先这样吧，之后再慢慢补充内容。


